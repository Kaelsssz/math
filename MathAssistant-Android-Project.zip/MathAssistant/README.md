# Math Assistant — Android / Brave

A native Android prototype for user-authorized screen capture, on-device ML Kit OCR, and basic math guidance. It displays a floating panel over Brave. It does not click, fill, or submit Khan Academy answers.

## Build in GitHub Codespaces

Requires JDK 17, Gradle 8.9, Android SDK platform 35, and Android build-tools 35.0.0.

```bash
java -version
gradle --version
gradle wrapper --gradle-version 8.9
./gradlew :app:assembleDebug
```

If the SDK is not installed, install Android command-line tools and then:

```bash
sdkmanager "platform-tools" "platforms;android-35" "build-tools;35.0.0"
```

Set `ANDROID_HOME` to the SDK directory and add `$ANDROID_HOME/platform-tools` to `PATH`.

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

## Install on your Android phone

1. Download the debug APK from the Codespaces file explorer.
2. Transfer it to the phone and open it.
3. Allow installation from that source if Android asks.
4. Launch Math Assistant.
5. Grant **Display over other apps** permission.
6. Tap **Start screen assistant** and approve Android's screen-capture consent dialog.
7. Switch to Brave, open the math exercise, and tap **Scan visible question**.
8. Review the recognized text and math guidance. Verify the OCR against the original screen.

## Limitations and privacy

- Screen capture always requires explicit Android consent. Android displays an ongoing screen-sharing indicator.
- Stop capture using the app or Android's screen-sharing controls.
- This starter solver evaluates simple arithmetic expressions and provides basic topic hints. It is not a full algebra/CAS engine or hosted AI model.
- ML Kit Latin OCR can misread fractions, superscripts, and mathematical layout. Zoom in and verify the recognized text.
- Some protected screens may be blank in captures. The app does not bypass secure-window protections.
- OCR is processed on-device. No screenshots or recognized text are uploaded.
- For Android 14+, start a fresh screen-capture session after stopping the previous one.
