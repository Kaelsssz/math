package com.mathassistant

import java.math.BigDecimal
import java.math.RoundingMode

object MathSolver {
    fun analyze(ocrText: String): String {
        val text = ocrText.trim()
        if (text.isEmpty()) return "No readable text found. Zoom in and scan again."

        val pattern = Regex("(-?\\d+(?:\\.\\d+)?)\\s*([+−×÷*/])\\s*(-?\\d+(?:\\.\\d+)?)")
        val match = pattern.find(text)
        if (match != null) {
            val a = match.groupValues[1].toBigDecimalOrNull()
            val op = match.groupValues[2]
            val b = match.groupValues[3].toBigDecimalOrNull()
            if (a != null && b != null) {
                val answer = try {
                    when (op) {
                        "+" -> a.add(b)
                        "-", "−" -> a.subtract(b)
                        "*", "×" -> a.multiply(b)
                        "/", "÷" -> if (b.compareTo(BigDecimal.ZERO) == 0) null
                                    else a.divide(b, 10, RoundingMode.HALF_UP).stripTrailingZeros()
                        else -> null
                    }
                } catch (_: Exception) { null }
                if (answer != null) return "Detected: ${match.value}\nCalculated result: ${answer.stripTrailingZeros().toPlainString()}\n\nVerify that OCR read the symbols correctly."
                if (op == "/" || op == "÷") return "Division by zero is undefined."
            }
        }

        val hint = when {
            text.contains("slope", true) -> "Slope: m = (y₂ − y₁) / (x₂ − x₁)."
            text.contains("quadratic", true) || text.contains("²") ->
                "Quadratic: arrange as ax² + bx + c = 0; use factoring or the quadratic formula."
            text.contains("percent", true) -> "Percentage = (part ÷ whole) × 100%."
            text.contains("fraction", true) -> "For addition/subtraction, find a common denominator. For multiplication, multiply numerators and denominators."
            else -> "The OCR text is shown above. This starter solver does not yet solve this problem type automatically."
        }
        return "RECOGNIZED TEXT\n$text\n\nMATH GUIDANCE\n$hint\n\nCheck exponents, signs, fractions, and answer choices against the screen."
    }
}
