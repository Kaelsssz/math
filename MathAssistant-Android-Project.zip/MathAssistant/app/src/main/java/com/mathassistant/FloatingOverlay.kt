package com.mathassistant

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class FloatingOverlay(private val context: Context, private val onScan: () -> Unit) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: LinearLayout? = null
    private var resultView: TextView? = null

    fun show() {
        if (root != null) return
        val panel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(Color.rgb(30, 32, 38))
        }
        panel.addView(TextView(context).apply {
            text = "Math Assistant"
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
        })
        panel.addView(Button(context).apply {
            text = "Scan visible question"
            setOnClickListener { onScan() }
        })
        val output = TextView(context).apply {
            text = "Open an exercise in Brave, then tap Scan."
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(4, 10, 4, 10)
        }
        panel.addView(ScrollView(context).apply { addView(output) },
            LinearLayout.LayoutParams(-1, 360))
        panel.addView(Button(context).apply {
            text = "Close assistant"
            setOnClickListener { remove() }
        })
        val params = WindowManager.LayoutParams(
            310, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 120 }
        try {
            wm.addView(panel, params)
            root = panel
            resultView = output
        } catch (_: Exception) { }
    }

    fun showResult(text: String) { resultView?.post { resultView?.text = text } }
    fun remove() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        resultView = null
    }
}
